package com.daya.flight.MakeMyTrip;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;



import com.daya.flight.pojo.FlightsPojo;

public class FlightDetails {
	ArrayList<FlightsPojo> flightsList=new ArrayList<FlightsPojo>();
	
	ArrayList<FlightsPojo> sortList=new ArrayList<FlightsPojo>();
	public void addFlightDetails(FlightsPojo flight) {
		flightsList.add(flight);
	}
	
	public ArrayList<FlightsPojo> removeFlightById(int flightNo) {
		for(FlightsPojo remove:flightsList) {
			if(remove.getFlightNo()==flightNo) {
				flightsList.remove(flightNo);
				return flightsList;
			}
		}
		throw new RuntimeException("Flight doesn't exist");
	}

	public ArrayList<FlightsPojo> getFlightDetails() {
		return flightsList;
	}
	
	public ArrayList<FlightsPojo> updateFlightTime(int flightNo,int depTime,int arrTime)
	{
		for(FlightsPojo fli: flightsList) {
			if(fli.getFlightNo()==flightNo) {
				fli.setArrivalTime(arrTime);
				fli.setDepartTime(depTime);
				//fli.setTotTime(totTime);
				return flightsList;
			}
		}
		throw new RuntimeException("Flight does not exists");
	}

	public ArrayList<FlightsPojo> sortFlightsByMorning()
	{
		for(FlightsPojo fli:flightsList)
		{
			if(fli.getDepartTime()<12)
				return flightsList;
		}
		throw new RuntimeException("flight does not exist");
	}
	
	public ArrayList<FlightsPojo> updateDestination(int flightId,String destination){
		for(FlightsPojo update:flightsList) {
			if(update.getFlightNo()==flightId) {
				update.setDestination(destination);
				return flightsList;
			}
		}
		throw new RuntimeException("Flight doesn't exist");
	}
	
	public ArrayList<FlightsPojo> updateTime(int flightId,int arrivalTime,int departTime){
		for(FlightsPojo update:flightsList) {
			if(update.getFlightNo()==flightId) {
				update.setArrivalTime(arrivalTime);
				update.setDepartTime(departTime);
				return flightsList;
			}
		}
		throw new RuntimeException("Flight doesn't exist");
	}
	
	public ArrayList<FlightsPojo> sortByCheapestPrice(String source,String destination)
	{
			for(FlightsPojo flist:flightsList) {
			if(flist.getSource().equals(source) && flist.getDestination().equals(destination)) {
				sortList.add(flist);
			}
			}
			Collections.sort(sortList, new Comparator<FlightsPojo>() {
			public int compare(FlightsPojo fli1,FlightsPojo fli2)
			{
				return fli1.getCost()-fli2.getCost();
			}
			});	
		return sortList;
	}
}
